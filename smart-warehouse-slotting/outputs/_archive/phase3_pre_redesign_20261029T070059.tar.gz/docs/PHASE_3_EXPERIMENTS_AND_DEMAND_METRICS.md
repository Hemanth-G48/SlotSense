# Phase 3 — Demand-aware optimization, evaluation experiments, and replenishment metrics

**Date:** 2026-10-29
**Repo:** `/home/hemanth/hackathon/epoch_hackathon/smart-warehouse-slotting`
**Dataset:** `dataset/processed` (canonical, unmodified)
**Artifacts:** `outputs/phase3/` · **Machine-readable result:** `outputs/phase3/phase3_experiments.json`
**Predecessors:** `docs/PHASE_1_BASELINE_VERIFICATION.md`, `docs/PHASE_2_CONSTRAINT_ENGINE.md`, `reports/PHASE_2_REPORT.md`

---

## 1. Scope and acceptance criteria

Phase 3 answers six questions the PS implies but Phase 2 could not: (1) does demand-weighted travel
improve; (2) is the gain placement or fragmentation; (3) does it survive held-out demand; (4) what does
replenishment cost; (5) how sensitive is any of this to objective weights; (6) can every number be traced.

Acceptance: order-line travel published, 2×2 decomposition measured, fit/holdout split with leakage checks,
replenishment metric with defined semantics, weight sweep, provenance manifest, EDA findings, dashboard data
contract — all with the Phase 2 hard constraints still gating.

## 2. Initial state (Phase 2, verified)

Optimized layout feasible (0 violations, 6,375/6,375 units); baseline repaired to feasibility with the
objective disabled (1,071 → 0 `CAT-01`, 93/1,200 SKUs moved, 0 quantity changes); evaluation gate blocks
infeasible comparisons; **181 tests passing**. The Phase 2 **−55.65 %** travel figure was computed **in-sample**
and is **not** a held-out result.

## 3. Metric contracts

| Metric | Definition | Numerator / denominator | Grain | Unit |
|---|---|---|---|---|
| `T` per line | sum of depot→bin distances for the stops that line causes | — | order line | m |
| `demand_weighted_depot_distance` | `Σ_lines T(line)` | numerator = total metres; denominator = number of lines | workload | m |
| `mean_per_line_m` | `numerator / denominator` | as stated | line | m |
| pick-cycle time | travel/1.3 + 8 s×lines + 10 s×batch | — | batch | s |
| throughput | orders / total cycle hours | orders / hours | workload | orders/h |
| cube utilisation | occupied volume / usable stockable volume | cm³ / cm³ | warehouse | % |
| replenishment travel | `Σ_(s,b) 2 · trips(s,b) · depot_distance(b)` | metres / SKU | layout | m |

**Why the aggregate is "demand-weighted" without a second weight:** the unit of account is the order line. A
SKU ordered in 200 lines contributes 200 distances; one ordered once contributes one. Multiplying by quantity
again would double-count — quantity only decides how many bins a line visits under the quantity-aware rule.

**Conflict resolved conservatively:** Phase 2's objective summed `demand × distance` **per assignment record**,
which charges a SKU once per bin it occupies. That is retained in the optimizer's own accounting but is **not**
the published metric, and the two are explicitly separated (§10).

## 4. Order-line travel implementation

`src/experiments/travel.py`. Two pick rules, both computed from the same layout and distance model:

- **`all_bins`** — the picker visits every bin holding the SKU (the v1 simulator's assumption). Distance = Σ
  depot→bin over all of that SKU's bins.
- **`quantity_aware`** — the picker visits the nearest bins until the line's quantity is covered; spilled lines
  add the next nearest bin.

Lines whose SKU has no assigned bin are **reported** (`lines_unresolved`), never dropped and never priced at 0.
A bin with no distance is likewise counted as unresolved rather than silently costing nothing.

## 5. Demand-weighted travel — publication

Written to `outputs/phase3/phase3_experiments.json` (`two_by_two.cells[]`) and to the per-line audit files
`outputs/phase3/line_travel_<layout>_<rule>.csv` (one row per order line: stops, stop count, distance). The
aggregate carries `numerator_m`, `denominator_lines` and `mean_per_line_m` so the number is reproducible from
the audit file alone.

## 6. The 2×2 experiment

**Factors.** Placement = `baseline_repaired` vs `optimized_fit`. Pick rule = `all_bins` vs `quantity_aware`.
**Controlled:** same warehouse, products, inventory, hard constraints, radius, distance model, holdout
workload, and batching policy. Single deterministic run — this is a decomposition, not a significance test.

Holdout workload: 5,997 order lines.

| Cell | Placement | Pick rule | Feasible | `demand_weighted_depot_distance` | Stops | Mean/line |
|---|---|---|---|---|---|---|
| A1 | baseline_repaired | all_bins | ✅ | 694,576.0 m | 8,159 | 115.82 m |
| A2 | baseline_repaired | quantity_aware | ✅ | 501,569.0 m | 6,164 | 83.64 m |
| B1 | optimized_fit | all_bins | ✅ | 273,292.0 m | 6,258 | 45.57 m |
| B2 | optimized_fit | quantity_aware | ✅ | 259,336.6 m | 6,033 | 43.24 m |

**Effects** (Y = travel, so negative = improvement):

| Effect | Value | Reading |
|---|---|---|
| Placement (average over rules) | **−331,758.2 m** (−66.14 % of the quantity-aware baseline) | the optimized layout is closer, under either rule |
| Pick rule (average over layouts) | **+103,481.2 m** (+20.63 %) | the all-bins rule charges more stops than quantity-aware |
| **Interaction (difference-in-differences)** | **−179,051.5 m** | the optimized layout gains *more* under the all-bins rule |
| **Placement effect under quantity-aware** | **−242,232.4 m (−48.29 %)** | the defensible held-out improvement |

**Interpretation.** Of the raw gain measured under the all-bins rule, **54.0 %** is attributable to the
interaction — i.e. to fragmentation-sensitive visiting, not to placing the same visits closer. The honest
headline is therefore **−48.29 %** (quantity-aware, held out), not the −66 % the all-bins rule suggests.

## 7. Fit/holdout split and leakage checks

`src/experiments/split.py`. **Temporal, order-level**: orders sorted by `order_timestamp` then `order_id`;
first 70 % is the fit view, last 30 % the holdout. Order-level because a basket shares one picking trip;
temporal because a random split would let a layout be fitted on later history and evaluated on earlier.

| View | Scenario id | Orders | Lines | SKUs with demand | Window |
|---|---|---|---|---|---|
| fit | `A_FIT` | 3,790 | 14,003 | 1,103 | earliest 70 % by timestamp |
| holdout | `A_HOLDOUT` | 1,625 | 5,997 | 899 | latest 30 % by timestamp |

Each view is a **complete tree**, not an orders-only slice: `demand_summary` and `sku_affinity` are
**recomputed per view**, which is what prevents fit from seeing holdout demand. The physical tables
(warehouse, products, inventory, baseline, graph) are copied unchanged — the warehouse does not change
between two halves of a year.

**Leakage checks, all passing** (`split.checks` in the result JSON): disjoint orders · union equals input
population · scenario ids rewritten per view · fit lines belong to fit orders · holdout lines belong to
holdout orders · no line in both views · line counts match the manifest. The split rebuilds to identical
hashes, so it is reproducible without a seed.

**Fit used only fit data.** `run_phase5` gained `fit_scenario` / `affinity_scenario` parameters (defaults
preserve Phase 2 behaviour); the Phase 3 run passes `A_FIT` for both, so demand **and** affinity are mined on
fit demand only.

## 8. Replenishment semantics and metric

The dataset has no replenishment events, no supplier data and no restock policy. What it does have is on-hand
per bin, demand over a known window, and depot distances. The supported proxy:

```
daily_units(s) = units_demanded(s) / window_days          window_days = 180
lot(s)         = ceil(daily_units(s) × cover_days)        cover_days  = 14 (assumption)
trips(s, b)    = ceil(on_hand(s, b) / lot(s))
travel         = Σ_(s,b) 2 × trips(s, b) × depot_distance(b)
```

| Layout (holdout demand) | Trips | Replenishment travel | Mean per SKU | Bins |
|---|---|---|---|---|
| baseline_repaired | 4,390 | **817,730.8 m** | 681.4 m | 1,425 |
| optimized_fit | 4,369 | **542,486.8 m** | 452.1 m | 1,290 |

**−33.66 % restock travel**, driven almost entirely by the 135 fewer bins rather than by fewer trips — which
is the fragmentation effect the metric exists to expose.

**Limitations, stated not hidden:** no schedule, no trip batching, no vehicle capacity, no labour cost,
`cover_days` is an assumption. This is a proxy for restock *travel*, not an operational plan.

**Objective integration — not wired.** The term (`replenishment_term`) is implemented and unit-tested, but the
optimizer's objective does not yet weight it. Phase 3 measures the trade-off; enabling it would re-tune the
layout and belongs to Phase 4. Recorded as a blocker, not a claim.

## 9. Weight sensitivity

`src/experiments/sweep.py` logic lives in the runner; four vectors over the existing weights, all fitted on
`A_FIT` and evaluated once on holdout:

| Config | α | β | γ | δ | Fit feasible | Fit objective | Holdout T |
|---|---|---|---|---|---|---|---|
| default | 1.0 | 0.4 | 0.3 | 0.2 | ✅ | 625,551.4 | 259,336.6 |
| **travel_only** ← selected | 1.0 | 0.0 | 0.0 | 0.0 | ✅ | **622,469.0** | 259,336.6 |
| affinity_heavy | 1.0 | 1.0 | 0.3 | 0.2 | ✅ | 628,588.2 | 259,336.6 |
| ergonomics_heavy | 1.0 | 0.4 | 1.0 | 0.2 | ✅ | 627,084.4 | 259,336.6 |

**The finding is the flatness.** All four vectors produce **identical** held-out travel (259,336.575 m). The
weights change the objective by ~1 % and the layout not at all — the greedy is dominated by travel and the
other terms are too small to move a placement. Selection used the **fit** objective only (`travel_only`
wins); holdout was reported for every variant but never used to choose.

## 10. Objective and evaluation integrity

- Hard feasibility is separate from objective value: `feasibility_status` comes from the validator, never from
  the objective.
- The optimizer's internal `demand × distance` (per record) is not the published metric; the published
  `demand_weighted_depot_distance` is per line (§3–§5).
- Every rate publishes numerator and denominator; no percentage is computed from a zero denominator.
- The Phase 2 gate still blocks infeasible comparisons; the Phase 3 fit run is `FEASIBLE` with 0 violations.
- The Phase 2 **−55.65 %** is labelled **in-sample** everywhere it appears and is not quoted as held-out.

## 11. Provenance

`outputs/phase3/provenance.json` (schema `phase3.provenance/1`): per-table SHA-256 for the processed dataset,
the generator manifest reference, config path + hash + full config, split manifest path + hash, software
versions (python/pandas/numpy/platform), output paths + hashes + row counts, and a `limitations` list that
records — rather than invents — what cannot be known: no VCS commit, synthetic data with no external licence
or retrieval date, single deterministic run per configuration, replenishment as a proxy.

## 12. EDA findings (actual values, with consequences)

| Question | Result | Implication | Limitation |
|---|---|---|---|
| Demand concentration (Pareto/ABC) | A = **293 SKUs (24.4 %) carry 80.0 %** of demand; top 20 % carry 76.4 % | the golden-zone lever is ~293 SKUs, not 1,200 | ABC boundary puts the crossing SKU in B, so A holds slightly < 80 % |
| Affinity structure | 13,062 pairs; **5,114 clear co≥2 & lift≥1**; 457 SKUs fall in clusters, largest 10 | adjacency opportunities are sparse and small — consistent with the modest affinity effect and the flat weight sweep | threshold choice (lift≥5, co≥8 for clusters) determines cluster count |
| Volume vs capacity | **1,099 / 1,200** SKUs fit the median bin; median SKU occupies **2.3 %** of a bin; top 10 % of SKUs hold **67 %** of total volume | one SKU per bin wastes space for the long tail; consolidation (1,425 → 1,288 bins) is the real space lever | bounding-box volume, no 3-D packing |
| Relationship to layout results | the optimized layout is 48.3 % closer under quantity-aware picking, while restock travel falls 33.7 % from 135 fewer bins | placement and consolidation improve together here; they are not in tension on this dataset | single deterministic instance |

## 13. Dashboard data contract

`app/phase3_contract.py` exposes `load_phase3()` — split, baseline variant, cells with numerator/denominator,
effects, replenishment, sweep, feasibility and the evaluation status (`held_out` vs `in_sample_or_unverified`).
Missing artifacts return `"unavailable"` with the command that produces them; **nothing is defaulted to 0**.
The dashboard itself is not redesigned (out of scope); this is the contract a future view consumes.

## 14. Tests and results

```
.venv/bin/python -m pytest tests/test_phase3_metrics.py tests/test_phase3_experiments.py tests/test_phase3_contract.py -q
→ 25 passed in 0.44 s
```

Covers: single-SKU/single-line travel · demand weighting by line count · quantity-aware stop coverage and
spill · all-bins over-charging · no double multiplication by quantity · missing assignment reported ·
empty workload with no denominator · per-line table summing to the aggregate · lot sizing · replenishment
trips/travel hand-checked · replenishment growth under fragmentation · 2×2 cell values and effects on a
hand-calculated fixture · infeasible cells retained and flagged · split temporal ordering, disjointness,
reproducibility, demand recomputation per view, manifest fields · contract unavailability and status downgrade.

## 15. Limitations and blockers

1. **Replenishment term not wired into the objective** — metric and function exist, weight is 0.
2. **One deterministic instance, no seeds** — every effect is a decomposition, not a significance test.
3. **Split is temporal, not operational** — no seasonality model; the holdout is the later 30 % of one
   history.
4. **`cover_days = 14` is an assumption**, not a modelled policy.
5. **The affinity threshold makes Φ sparse** (5,114 of 13,062 pairs), which is consistent with the flat sweep
   but does not prove the term is useless under a different threshold.
6. **Dashboard wiring not done** — contract only (D28/D44 remain open).
7. **Historical artifacts still non-comparable** (Phase 1 E.3): the 382,544 m committed figure belongs to a
   different dataset build.

## 16. Reproduce

```bash
cd /home/hemanth/hackathon/epoch_hackathon/smart-warehouse-slotting

# full run (split -> fit -> 2x2 -> replenishment -> sweep -> provenance), ~3 min
.venv/bin/python -m src.experiments.run_phase3

# core path without the sweep, ~1 min
.venv/bin/python -m src.experiments.run_phase3 --skip-sweep

# tests
.venv/bin/python -m pytest tests/test_phase3_metrics.py tests/test_phase3_experiments.py tests/test_phase3_contract.py -q
```

Outputs land in `outputs/phase3/`; the canonical dataset is never written to.
