# Phase 3 Report — Demand-aware optimization, experiments, and replenishment

**Date:** 2026-10-29
**Repo:** `/home/hemanth/hackathon/epoch_hackathon/smart-warehouse-slotting`
**Dataset:** `dataset/processed` (canonical, unmodified) · **Artifacts:** `outputs/phase3/`
**Detail:** `docs/PHASE_3_EXPERIMENTS_AND_DEMAND_METRICS.md` (16 sections) · `outputs/phase3/phase3_experiments.json`

---

## Status

**PARTIALLY COMPLETE.**

Eleven of the fourteen definition-of-done items are fully met and evidenced; three are partial:
the **replenishment objective term is not wired** (metric and function exist, weight stays 0), the
**dashboard consumes a data contract rather than rendering it** (allowed by the brief, but wiring is undone),
and **no seed variability** was measured (one deterministic instance per configuration).

What *is* complete changes the project's headline: the held-out, quantity-aware improvement is **−48.29 %**,
and **54.0 %** of the raw gain under the all-bins rule is attributable to fragmentation rather than placement.
The Phase 2 **−55.65 %** is in-sample and is not quoted as a held-out result anywhere.

---

## Files changed

| File | Purpose |
|---|---|
| `src/experiments/travel.py` *(new)* | Order-line travel under two pick rules; `demand_weighted_depot_distance` with numerator/denominator; per-line audit table |
| `src/experiments/split.py` *(new)* | Temporal order-level fit/holdout split; complete trees with `demand_summary`/`sku_affinity` recomputed per view; 7 leakage checks |
| `src/experiments/factorial.py` *(new)* | 2×2 placement × pick-rule design; cell means, main effects, difference-in-differences |
| `src/experiments/replenishment.py` *(new)* | Restock-trip proxy: `trips(s,b)=ceil(on_hand/lot(s))`, travel `Σ 2·trips·depot_distance` |
| `src/experiments/provenance.py` *(new)* | Manifest: per-table/output SHA-256, config, split, software versions, explicit unknowns |
| `src/experiments/run_phase3.py` *(new)* | Runner: split → fit → 2×2 → replenishment → sweep → provenance |
| `app/phase3_contract.py` *(new)* | Dashboard data contract; missing values are `unavailable`, never 0 |
| `src/optimization/pipeline.py` | `fit_scenario` / `affinity_scenario` parameters (defaults preserve Phase 2 behaviour) so the optimizer cannot see holdout demand |
| `tests/test_phase3_metrics.py`, `test_phase3_experiments.py`, `test_phase3_contract.py` *(new)* | 25 tests |
| `docs/PHASE_3_EXPERIMENTS_AND_DEMAND_METRICS.md` *(new)* | Full methodology and results |
| `ARCHITECTURE.md` | D22/D29/D35/D36/D46/D48 closed; R2.2, R3.3, D-3 verified; counts recounted |

---

## Metric definitions

```
T(line)        = Σ depot→bin distances for the stops that line causes
demand_weighted_depot_distance
               = Σ_over_lines T(line)
                 numerator   = total metres
                 denominator = number of order lines
mean_per_line_m = numerator / denominator
```

Unit: metres. Grain: order line aggregated to workload. Weighting: inherent in the line count — a SKU in 200
lines contributes 200 distances; quantity is **not** applied a second time (it only decides how many bins a
line visits under `quantity_aware`). Published in `phase3_experiments.json` and reproduced exactly by the
per-line audit CSVs (verified: file sum equals the published cell to the cent, 5,997 lines each).

---

## 2×2 experiment

Placement = `baseline_repaired` vs `optimized_fit`; pick rule = `all_bins` vs `quantity_aware`. Shared:
warehouse, products, inventory, constraints, radius 10 m, distance model, holdout workload, batching.

| Cell | Placement | Rule | Feasible | `demand_weighted_depot_distance` | Stops |
|---|---|---|---|---|---|
| A1 | baseline_repaired | all_bins | ✅ | 694,576.0 m | 8,159 |
| A2 | baseline_repaired | quantity_aware | ✅ | 501,569.0 m | 6,164 |
| B1 | optimized_fit | all_bins | ✅ | 273,292.0 m | 6,258 |
| B2 | optimized_fit | quantity_aware | ✅ | 259,336.6 m | 6,033 |

| Effect | Value |
|---|---|
| Placement (avg over rules) | **−331,758.2 m** (−66.14 % of the QA baseline) |
| Pick rule (avg over layouts) | **+103,481.2 m** (+20.63 %) |
| **Interaction (DiD)** | **−179,051.5 m** |
| **Placement under quantity-aware** | **−242,232.4 m (−48.29 %)** |

**Reading:** 54.0 % of the raw gain depends on the all-bins rule, i.e. on consolidation reducing the number of
bins visited. The defensible held-out figure is −48.29 %, not −66 %.

---

## Fit/holdout integrity

Temporal, **order-level** split (fit = earlier 70 % of history, holdout = later 30 %), no seed needed because
time ordering is total.

| View | Scenario | Orders | Lines | SKUs |
|---|---|---|---|---|
| fit | `A_FIT` | 3,790 | 14,003 | 1,103 |
| holdout | `A_HOLDOUT` | 1,625 | 5,997 | 899 |

Leakage checks (all pass): disjoint orders · union equals input population · scenario rewritten per view ·
fit lines ⊆ fit orders · holdout lines ⊆ holdout orders · no line in both · counts match manifest. Each view is
a complete tree with demand tables **recomputed**, and the optimizer runs with `fit_scenario=A_FIT`,
`affinity_scenario=A_FIT`. Rebuilding produces identical hashes.

---

## Replenishment

`trips(s,b) = ceil(on_hand(s,b) / lot(s))`, `lot(s) = ceil(daily_units(s) × 14)`, `travel = Σ 2·trips·depot_distance`.

| Layout | Trips | Travel | Bin count |
|---|---|---|---|
| baseline_repaired | 4,390 | 817,730.8 m | 1,425 |
| optimized_fit | 4,369 | **542,486.8 m** | 1,290 |

**−33.66 %**, driven by 135 fewer bins rather than fewer trips. Limits: no schedule, no trip batching, no
vehicle capacity, no labour cost; `cover_days=14` is an assumption. **The objective term is not wired** —
`replenishment_term()` exists and is unit-tested, but the optimizer's weight is 0.

---

## Weight sensitivity

| Config | α | β | γ | δ | Feasible | Fit objective | Holdout T |
|---|---|---|---|---|---|---|---|
| default | 1.0 | 0.4 | 0.3 | 0.2 | ✅ | 625,551.4 | 259,336.6 |
| **travel_only** (selected) | 1.0 | 0.0 | 0.0 | 0.0 | ✅ | **622,469.0** | 259,336.6 |
| affinity_heavy | 1.0 | 1.0 | 0.3 | 0.2 | ✅ | 628,588.2 | 259,336.6 |
| ergonomics_heavy | 1.0 | 0.4 | 1.0 | 0.2 | ✅ | 627,084.4 | 259,336.6 |

**All four produce identical held-out travel.** The weights move the objective by ~1 % and the layout not at
all — the greedy is travel-dominated and the other terms are too small to change a placement. Selection used
the **fit** objective only; holdout was never used to choose.

---

## Provenance and EDA

`outputs/phase3/provenance.json` records per-table SHA-256, generator-manifest hash, config + hash + effective
radius, split-manifest hash, software versions, and output hashes + row counts. Unknowns are marked, not
invented: no VCS commit (not a git repo), no external licence or retrieval date (synthetic), no seed
variability, replenishment as a proxy. All hashes re-verified after the run.

EDA findings (actual values):

| Finding | Value | Consequence |
|---|---|---|
| Demand concentration | A = 293 SKUs (24.4 %) → 80.0 % of demand; top 20 % → 76.4 % | the golden-zone lever is ~293 SKUs |
| Affinity sparsity | 13,062 pairs, 5,114 clear co≥2/lift≥1; 457 SKUs clustered, largest 10 | adjacency opportunity is small — consistent with the flat sweep |
| Volume concentration | 1,099/1,200 SKUs fit the median bin; median SKU = 2.3 % of a bin; top 10 % hold 67 % of volume | one-SKU-per-bin wastes space for the long tail; consolidation is the space lever |

---

## Test results

```
.venv/bin/python -m pytest tests/ -q --tb=no -p no:cacheprovider
→ 206 passed in 245.00 s   (0 failed, 0 skipped)
```

25 of those are Phase 3 (`test_phase3_metrics.py`, `test_phase3_experiments.py`, `test_phase3_contract.py`),
covering hand-calculated travel values, quantity-aware spill, no double multiplication, missing assignments,
empty denominators, hand-calculated 2×2 effects, infeasible-cell retention, temporal split ordering and
reproducibility, per-view demand recomputation, and contract unavailability. No test was skipped, weakened or
removed; all 181 Phase 2 tests still pass.

---

## Benchmark results

| Item | Value |
|---|---|
| Baseline variant | `repaired_minimal` (1,071 → 0 `CAT-01`, 93/1,200 SKUs moved, 0 quantity changes) |
| Fit layout | `FEASIBLE`, 0 violations, 6,375/6,375 units, fitted on `A_FIT` only, 37.4 s |
| Held-out travel (quantity-aware) | 501,569.0 → **259,336.6 m = −48.29 %** |
| Raw (all-bins) comparison | 694,576.0 → 273,292.0 m = −60.65 %, of which 54.0 % is fragmentation |
| Restock travel | 817,730.8 → 542,486.8 m = −33.66 % |
| Hard constraints | 0 violations in every cell at 10 m |
| Inventory reconciliation | 6,375 = 6,375 in every layout; 0 duplicate rows; 0 unplaced SKUs |
| Runtime | fit run 37.4 s; sweep 4 × ~37 s |

---

## Remaining blockers

1. **Replenishment objective term not wired** — metric measured, weight 0; enabling it would re-tune layouts.
2. **Dashboard not wired** — contract only (`app/phase3_contract.py`); D28/D44 remain open.
3. **Single deterministic instance per configuration** — no seeds, so no confidence intervals; every effect is
   a decomposition, not a significance test.
4. **`cover_days=14` is an assumption**, not a modelled restock policy.
5. **Split is temporal on one history** — no seasonality or regime-change test.
6. **The affinity term is sparse** under the current thresholds (5,114 usable pairs), which explains the flat
   sweep but does not prove the term is useless under other thresholds.
7. **Historical artifacts remain non-comparable** (Phase 1 E.3).

---

## Phase 4 readiness

**Yes, for the parts Phase 3 established; no, for the three partial items.**

Ready: order-line travel and its published aggregate, the 2×2 decomposition, the leakage-safe split with
re-checks, the replenishment *metric*, the provenance manifest, the EDA findings and the dashboard contract are
all implemented, tested and reproducible.

Not ready: the replenishment term is still outside the objective, the dashboard reads a contract but renders
nothing new, and there is no uncertainty estimate on any effect. Phase 4 should either wire those three or state
explicitly that they are out of scope — and should not quote −48.29 % without also quoting the 54 % fragmentation
share beside it.
